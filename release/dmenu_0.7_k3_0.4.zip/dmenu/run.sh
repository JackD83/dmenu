#!/bin/sh
echo "staring dmenu" >>stdout.txt
./dmenuc.bin >>stdout.txt 2>> stderr.txt
echo "dmenu closed" >>stdout.txt