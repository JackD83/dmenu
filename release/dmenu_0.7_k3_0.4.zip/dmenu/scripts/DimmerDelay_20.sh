#!/bin/sh
sed  -i  '12 c\DimmerDelay = 20'  /mnt/mmc/dmenu/dmenu.ini
sync