#!/bin/sh
sed  -i  '10 c\Bright = 40'  /mnt/mmc/dmenu/dmenu.ini
sync
