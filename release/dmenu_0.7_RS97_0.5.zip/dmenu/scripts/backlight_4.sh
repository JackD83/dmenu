#!/bin/sh
sed  -i  '10 c\Bright = 60'  /mnt/mmc/dmenu/dmenu.ini
sync
