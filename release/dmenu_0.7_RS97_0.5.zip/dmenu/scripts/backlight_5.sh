#!/bin/sh
sed  -i  '10 c\Bright = 80'  /mnt/mmc/dmenu/dmenu.ini
sync
