--------------------------------------------
Handy320 v0.1 for Dingux and OpenDingux
--------------------------------------------

Based on:
Handy/SDL 0.5 (c) 2004 SDLemu team
Handy 0.95 (c) 2004 K. Wilkins
Gui browser is mostly copy-pasted from gpSP by Exophaze
icon is from coccioe's HandyOD

PACKAGE
There are 2 binaries in the archive,
handy320-od.dge - for OpenDingux (Dingoo A320)
handy320.dge - for legacy Dingux (Dingoo A380/320e, Ritmix rzx50)

INSTALL
Copy either handy320.dge or handy320-od.dge to some dir on your sd-card or inner flash-memory.
Find real lynxboot.img somewhere in the internet (Google is your friend) and put it in the same directory.

COMPATIBILITY
Handy320 supports Dingoo a320, a380 and Ritmix rzx50. Three fullscreen modes could be used:
320x240
400x240
480x272
They are detected automatically, you don't have to worry about them.
ON DINGOO A380 SHIFTS AND X/Y ARE SWAPPED! IT'S A FIRMWARE BUG!

BUTTONS
DINGOO D-PAD - Atari Lynx D-PAD
DINGOO A - Atari Lynx A
DINGOO B - Atari Lynx B
DINGOO X - Atari Lynx OPT2
DINGOO Y - Atari Lynx OPT1
DINGOO START - Atari Lynx PAUSE
DINGOO SELECT - exit
DINGOO L - open GUI
DINGOO R - toggle image scalers (simple2x / fullscreen)

D_smagin, exmortis at yandex ru