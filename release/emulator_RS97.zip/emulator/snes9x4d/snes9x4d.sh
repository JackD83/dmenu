#! /bin/sh

# flush lcd is needed for rzx-50 and, possibly, a380
echo 1 > /proc/jz/lcd_flush

# redefine HOME, because it points to read-only (appfs.ext3)/local/home
export HOME=/mnt/mmc/emulator/snes9x4d


# start actual emulator
cd /mnt/mmc/emulator/snes9x4d
LD_PRELOAD=../sdlfix.so ./snes9x4d.dge "$1"


# revert HOME
export HOME=/usr/local/home
