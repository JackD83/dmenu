#!/bin/sh
sed  -i  '12 c\DimmerDelay = 15'  /mnt/mmc/dmenu/dmenu.ini
sync