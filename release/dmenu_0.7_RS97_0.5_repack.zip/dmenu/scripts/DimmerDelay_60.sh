#!/bin/sh
sed  -i  '12 c\DimmerDelay = 60'  /mnt/mmc/dmenu/dmenu.ini
sync