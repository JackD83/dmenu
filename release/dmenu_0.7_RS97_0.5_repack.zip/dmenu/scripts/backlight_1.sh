#!/bin/sh
sed  -i  '10 c\Bright = 20'  /mnt/mmc/dmenu/dmenu.ini
sync
