#!/bin/sh
sed  -i  '12 c\DimmerDelay = 10'  /mnt/mmc/dmenu/dmenu.ini
sync