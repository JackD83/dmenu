#! /bin/sh

# flush lcd is needed for rzx-50 and, possibly, a380
echo 1 > /proc/jz/lcd_flush

# redefine HOME, because it points to read-only (appfs.ext3)/local/home
export HOME=/mnt/mmc/emulator/fba



cd /mnt/mmc/emulator/fba

if [ ! -e ./.fba/fba.swp ]; then
    dd if=/dev/zero of=./.fba/fba.swp bs=2048 count=65536
fi

mkswap ./.fba/fba.swp
swapon ./.fba/fba.swp

# start actual emulator
./fbasdl.dge "$1" --sound-sdl --samplerate=22050

swapoff ./.fba/fba.swp


# revert HOME
export HOME=/usr/local/home
