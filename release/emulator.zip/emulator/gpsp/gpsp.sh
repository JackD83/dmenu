#!/bin/sh

# flush lcd is needed for rzx-50 and, possibly, a380
echo 1 > /proc/jz/lcd_flush

# redefine HOME, because it points to read-only (appfs.ext3)/local/home
export HOME=/mnt/mmc/emulator/gpsp

# start actual emulator
cd /mnt/mmc/emulator/gpsp
./gpsp.dge "$1"

# revert HOME
export HOME=/usr/local/home
